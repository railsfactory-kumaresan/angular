<?php return array(
/**
 * Theme configuration goes there
 */
    'name'    => 'BonPress',   	 // theme name
    'styled'  => true,            	 // true if current theme supports styling
    'scripts' => array('dropdown', 'custom')     // javascripts theme uses
);