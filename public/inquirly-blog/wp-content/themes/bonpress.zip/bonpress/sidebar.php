<div class="collapse-trigger"><?php _e('View Sidebar', 'wpzoom'); ?><span></span></div>

<div id="sidebar">
	<?php if ( function_exists('dynamic_sidebar') ) dynamic_sidebar('Sidebar'); ?>
</div>